#import <Flutter/Flutter.h>

@interface SmartAuthPlugin : NSObject<FlutterPlugin>
@end
