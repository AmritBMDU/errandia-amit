import 'package:flutter_web_plugins/flutter_web_plugins.dart';

/// Fake implementation of Smart Auth Web
class SmartAuthWeb {
  static void registerWith(Registrar registrar) {}
}
