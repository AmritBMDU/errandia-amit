/// Flutter package for listening SMS code on Android, suggesting phone number, email, saving a credential.

library smart_auth;

export 'src/smart_auth.dart';
