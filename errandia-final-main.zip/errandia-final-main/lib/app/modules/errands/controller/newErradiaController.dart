import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class new_errandia_controller extends GetxController{
  TextEditingController title= TextEditingController();
  TextEditingController description= TextEditingController();
}