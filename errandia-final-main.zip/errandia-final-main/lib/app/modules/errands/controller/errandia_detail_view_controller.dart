import 'package:get/get.dart';
class errandia_detail_view_controller extends GetxController{

  RxBool isRead=false.obs;
}