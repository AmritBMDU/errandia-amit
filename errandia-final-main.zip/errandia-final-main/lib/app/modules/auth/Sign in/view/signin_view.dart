import 'package:errandia/app/APi/apidomain%20&%20api.dart';
import 'package:errandia/app/AlertDialogBox/alertBoxContent.dart';
import 'package:errandia/app/modules/auth/Register/buyer/view/otp_verification_screen.dart';
import 'package:errandia/app/modules/auth/Register/register_signin_screen.dart';
import 'package:errandia/app/modules/auth/Register/register_ui.dart';
import 'package:errandia/app/modules/auth/Sign%20in/view/signin_otp_verification_screen.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../../../home/view/home_view.dart';

class signin_view extends StatefulWidget {
  @override
  State<signin_view> createState() => _signin_viewState();
}

class _signin_viewState extends State<signin_view> {
  TextEditingController mobileno = TextEditingController();

  TextEditingController password = TextEditingController();

bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        elevation: 0.8,
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Color(0xff113d6b),
          ),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 15,
          ),
          child: ListView(
            children: [
              SizedBox(
                height: Get.height * 0.025,
              ),

              SizedBox(
                height: Get.height * 0.015,
              ),
              Container(
                child: Column(
                  children: [
                    Text(
                      'LOGIN TO YOUR ERRANDIA ACCOUNT',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                        color: Color(0xff113d6b),
                      ),
                      textAlign: TextAlign.center,
                    ),
                    // Text(
                    //   'ACCOUNT',
                    //   style: TextStyle(
                    //     fontSize: 26,
                    //     fontWeight: FontWeight.w700,
                    //     color: Color(0xff113d6b),
                    //   ),
                    // ),
                  ],
                ),
              ),

              //

              SizedBox(
                height: Get.height * 0.03,
              ),

              //
              Container(
                child: Column(
                  children: [
                    Text(
                      'Log into your Errandia account',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w500,
                        color: Color(0xff8ba0b7),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(
                height: Get.height * 0.1,
              ),
              Text(
                'Phone Number',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),

              SizedBox(
                height: Get.height * 0.003,
              ),
              Container(
                height: Get.height * 0.09,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Color(0xffe0e6ec),
                  ),
                  color: Colors.white,
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: SizedBox(

                        width: Get.width* 0.86,
                        child: IntlPhoneField(
                          controller: mobileno,

                          decoration: InputDecoration(
                              hintText: 'Enter Mobile Number',
                              contentPadding: EdgeInsets.only(top: 22),
                              border:InputBorder.none
                          ),

                          initialCountryCode: 'IN',
                          validator: (value){
                            if(value == null){
                              print(value);

                            }
                          },
                          onChanged: (phone) {
                            print(phone);
                          },
                        ),
                      ),
                    ),

                    Expanded(
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          vertical: 1,
                        ),
                        child: TextFormField(
                          maxLength: 10,
                          keyboardType: TextInputType.phone,
                          style: TextStyle(
                            fontSize: 18,
                          ),
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            counter: Offstage(),
                          ),
                        ),
                      ),
                    ),

                    // by registering
                  ],
                ),
              ),
              SizedBox(
                height: Get.height * 0.02,
              ),

              // buiseness email

              Text(
                'Password',
                style: TextStyle(
                  fontSize: 16,
                ),
              ),

              SizedBox(
                height: Get.height * 0.003,
              ),

              // text form field
              Container(
                height: Get.height * 0.08,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Color(0xffe0e6ec),
                  ),
                  color: Colors.white,
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Container(
                    child: TextFormField(
                      obscureText: true,
                      controller: password,
                      keyboardType: TextInputType.emailAddress,
                      style: TextStyle(
                        fontSize: 18,
                      ),
                      decoration:
                      InputDecoration(border: InputBorder.none,
                      hintText: 'Enter Password'
                      ),
                    ),
                  ),
                ),
              ),


            SizedBox(height: Get.height*0.1,),
              //button container

              InkWell(
                onTap: () {
                  var Phone = mobileno.text.trim();
                  var Password = password.text.trim();
                  if(Phone == ''&& Password == ''){
                    alertBoxdialogBox(context, 'Alert', 'Please Enter Fill Field');
                  }else {
                    var value = {
                      "phone":Phone,
                      "password":Password
                    };
                    Home_view home = Home_view();
                    api().registration('login', value, context, home,'');
                    setState(() {
                      isLoading =true;
                    });
                    Future.delayed(Duration(seconds: 2),(){
                      setState(() {
                        isLoading = false;
                      });
                    });
                  }

                },
                child: Container(
                  height: Get.height * 0.09,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Color(0xffe0e6ec),
                    ),
                    color: Color(0xff113d6b),
                  ),
                  child: Center(
                    child:isLoading == false? Text(
                      'CONTINUE',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ):Center(child: CircularProgressIndicator(color: Colors.white,),),
                  ),
                ),
              ),
              SizedBox(
                height: Get.height * 0.07,
              ),

              Align(
                alignment: Alignment.center,
                child: RichText(
                  text: TextSpan(
                      style: TextStyle(color: Color(0xff8ba0b7), fontSize: 17),
                      children: [
                        TextSpan(text: 'Don\'t have an Errandia Account? '),
                        TextSpan(
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              debugPrint('Register View');
                              Get.off(Register_Ui());
                            },
                          text: 'Register',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff3c7fc6),
                          ),
                        )
                      ]),
                ),
              ),
              SizedBox(
                height: Get.height * 0.03,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
