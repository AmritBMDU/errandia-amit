class following_model{
  String ? name;
  String ? picurl;
  String ? location;
  bool? isSelected;
  bool ? button_is_open;
  following_model({this.name, this.location  ,this.picurl, this.isSelected, this.button_is_open=false});

}