import 'package:flutter/material.dart';
import 'package:get/get.dart';

class add_product_cotroller extends GetxController{
  TextEditingController product_name_controller= TextEditingController();
  TextEditingController shop_Id_controller= TextEditingController();
  TextEditingController category_controller= TextEditingController();
  TextEditingController product_desc_controller= TextEditingController();
  TextEditingController product_tags_controller= TextEditingController();
  TextEditingController unit_price_controller= TextEditingController();
}